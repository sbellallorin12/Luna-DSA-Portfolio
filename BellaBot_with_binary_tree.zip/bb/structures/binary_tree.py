class TreeNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None


class BinaryTree:
    """Binary search tree: smaller keys go left, larger keys go right."""

    def __init__(self):
        self.root = None

    # ---------- insert (needed so there is something to work with) ----------
    def insert(self, key):
        if self.root is None:
            self.root = TreeNode(key)
            return True
        cur = self.root
        while True:
            if key == cur.data:
                return False                    # no duplicates
            if key < cur.data:
                if cur.left is None:
                    cur.left = TreeNode(key)
                    return True
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = TreeNode(key)
                    return True
                cur = cur.right

    # ---------- the three lab methods ----------
    def search(self, root, key):
        """Return the node holding key, or None if it is not in the tree."""
        if root is None or root.data == key:
            return root
        if key < root.data:
            return self.search(root.left, key)
        return self.search(root.right, key)

    def post_traversal(self, start, traversal):
        """Left -> Right -> Root. Returns the traversal string, e.g. '1-3-2-'."""
        if start:
            traversal = self.post_traversal(start.left, traversal)
            traversal = self.post_traversal(start.right, traversal)
            traversal += str(start.data) + "-"
        return traversal

    def delete_node(self, root, key):
        """Delete key from the subtree at root and return the new subtree root."""
        if root is None:
            return root
        if key < root.data:
            root.left = self.delete_node(root.left, key)
        elif key > root.data:
            root.right = self.delete_node(root.right, key)
        else:
            # Case 1 & 2: zero or one child -> replace node with that child
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left
            # Case 3: two children -> copy in-order successor, then delete it
            succ = root.right
            while succ.left:
                succ = succ.left
            root.data = succ.data
            root.right = self.delete_node(root.right, succ.data)
        return root

    # ---------- helpers for the web page ----------
    def remove(self, key):
        if self.search(self.root, key) is None:
            return False
        self.root = self.delete_node(self.root, key)
        return True

    def postorder_text(self):
        return self.post_traversal(self.root, "").rstrip("-").replace("-", " → ")

    def clear(self):
        self.root = None
