from flask import Blueprint, render_template, request

from structures.binary_tree import BinaryTree
from structures.deque import Deque
from structures.geometry import circle_area, to_number, triangle_area
from structures.linked_list import LinkedList
from structures.postfix import infix_to_postfix
from structures.queue import Queue

works_bp = Blueprint('works', __name__, url_prefix='/works')

# These live in memory while the server runs.
linked = LinkedList()
queue = Queue()
deque_ds = Deque()
tree = BinaryTree()


@works_bp.route('/')
def home():
    return render_template('works.html')


@works_bp.route('/uppercase', methods=['GET', 'POST'])
def uppercase():
    result = None
    if request.method == 'POST':
        result = request.form.get('inputString', '').upper()
    return render_template('touppercase.html', result=result)


@works_bp.route('/area/circle', methods=['GET', 'POST'])
def circle():
    result = error = None
    if request.method == 'POST':
        r = to_number(request.form.get('radius'))
        if r is None:
            error = 'Enter a radius of 0 or more.'
        else:
            result = circle_area(r)
    return render_template('circle.html', result=result, error=error)


@works_bp.route('/area/triangle', methods=['GET', 'POST'])
def triangle():
    result = error = None
    if request.method == 'POST':
        b = to_number(request.form.get('base'))
        h = to_number(request.form.get('height'))
        if b is None or h is None:
            error = 'Enter a base and height of 0 or more.'
        else:
            result = triangle_area(b, h)
    return render_template('triangle.html', result=result, error=error)


@works_bp.route('/linkedlist', methods=['GET', 'POST'])
def linkedlist():
    message = None
    if request.method == 'POST':
        action = request.form.get('action')
        value = request.form.get('value', '').strip()
        if action == 'reverse':
            linked.reverse()
            message = 'List reversed.'
        elif action == 'clear':
            linked.clear()
            message = 'List cleared.'
        elif not value:
            message = 'Enter a value first.'
        elif action == 'append':
            linked.append(value)
            message = f'Added "{value}" to the end.'
        elif action == 'prepend':
            linked.prepend(value)
            message = f'Added "{value}" to the front.'
        elif action == 'delete':
            ok = linked.delete(value)
            message = f'Deleted "{value}".' if ok else f'"{value}" is not in the list.'
        elif action == 'search':
            i = linked.search(value)
            message = f'"{value}" is at position {i}.' if i >= 0 else f'"{value}" is not in the list.'
    return render_template('linkedlist.html', items=linked.to_list(), message=message)


@works_bp.route('/postfix', methods=['GET', 'POST'])
def postfix():
    expr = result = error = None
    steps = []
    if request.method == 'POST':
        expr = request.form.get('expression', '')
        try:
            result, steps = infix_to_postfix(expr)
        except ValueError as e:
            error = str(e)
    return render_template('postfix.html', expr=expr, result=result, error=error, steps=steps)


@works_bp.route('/queue', methods=['GET', 'POST'])
def queue_page():
    message = None
    if request.method == 'POST':
        action = request.form.get('action')
        value = request.form.get('value', '').strip()
        if action == 'enqueue':
            if value:
                queue.enqueue(value)
                message = f'Enqueued "{value}".'
            else:
                message = 'Enter a value first.'
        elif action == 'dequeue':
            x = queue.dequeue()
            message = f'Dequeued "{x}".' if x is not None else 'The queue is empty.'
        elif action == 'peek':
            x = queue.peek()
            message = f'Front is "{x}".' if x is not None else 'The queue is empty.'
        elif action == 'clear':
            queue.clear()
            message = 'Queue cleared.'
    return render_template('queue.html', items=queue.items, message=message)


@works_bp.route('/deque', methods=['GET', 'POST'])
def deque_page():
    message = None
    if request.method == 'POST':
        action = request.form.get('action')
        value = request.form.get('value', '').strip()
        if action in ('add_front', 'add_rear'):
            if value:
                getattr(deque_ds, action)(value)
                where = 'front' if action == 'add_front' else 'rear'
                message = f'Added "{value}" to the {where}.'
            else:
                message = 'Enter a value first.'
        elif action in ('remove_front', 'remove_rear'):
            x = getattr(deque_ds, action)()
            where = 'front' if action == 'remove_front' else 'rear'
            message = f'Removed "{x}" from the {where}.' if x is not None else 'The deque is empty.'
        elif action == 'clear':
            deque_ds.clear()
            message = 'Deque cleared.'
    return render_template('deque.html', items=deque_ds.items, message=message)


@works_bp.route('/binarytree', methods=['GET', 'POST'])
def binarytree():
    message = None
    if request.method == 'POST':
        action = request.form.get('action')
        raw = request.form.get('value', '').strip()
        if action == 'clear':
            tree.clear()
            message = 'Tree cleared.'
        elif action == 'postorder':
            message = 'Post-order: ' + tree.postorder_text() if tree.root else 'The tree is empty.'
        else:
            try:
                key = int(raw)
            except ValueError:
                key = None
            if key is None:
                message = 'Enter a whole number first.'
            elif action == 'insert':
                message = f'Inserted {key}.' if tree.insert(key) else f'{key} is already in the tree.'
            elif action == 'search':
                found = tree.search(tree.root, key)
                message = f'{key} is in the tree.' if found else f'{key} is not in the tree.'
            elif action == 'delete':
                message = f'Deleted {key}.' if tree.remove(key) else f'{key} is not in the tree.'
    return render_template('binarytree.html', root=tree.root, message=message)
