from flask import Flask

from routes.main import main_bp
from routes.works import works_bp


def create_app():
    app = Flask(__name__)
    app.register_blueprint(main_bp)
    app.register_blueprint(works_bp)
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
