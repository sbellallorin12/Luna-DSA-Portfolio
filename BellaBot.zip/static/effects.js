(function () {
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var SPARKS = ['✦', '♥', '✧', '❀', '★'];

  // theme toggle (remembers your choice)
  var root = document.documentElement, btn = document.getElementById('theme');
  try { var saved = localStorage.getItem('theme'); if (saved) root.setAttribute('data-theme', saved); } catch (e) {}
  if (btn) btn.addEventListener('click', function () {
    var dark = getComputedStyle(root).getPropertyValue('--bg').trim() === '#26091b';
    var next = dark ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('theme', next); } catch (e) {}
  });
  if (reduce) return;

  function spawn(x, y, ch, dx, dy, size, life) {
    var el = document.createElement('span');
    el.className = 'fx'; el.textContent = ch;
    el.style.cssText = 'left:' + x + 'px;top:' + y + 'px;font-size:' + size + 'px;color:' +
      (Math.random() > .5 ? 'var(--accent)' : 'var(--accent2)');
    document.body.appendChild(el);
    el.animate([
      { transform: 'translate(0,0) scale(1) rotate(0)', opacity: 1 },
      { transform: 'translate(' + dx + 'px,' + dy + 'px) scale(.2) rotate(' + (dx * 3) + 'deg)', opacity: 0 }
    ], { duration: life, easing: 'ease-out' }).onfinish = function () { el.remove(); };
  }

  // sparkle trail behind the cursor
  var last = 0;
  window.addEventListener('mousemove', function (e) {
    var now = Date.now(); if (now - last < 55) return; last = now;
    spawn(e.clientX, e.clientY, SPARKS[Math.floor(Math.random() * SPARKS.length)],
      (Math.random() - .5) * 40, 25 + Math.random() * 30, 10 + Math.random() * 10, 800);
  });

  // heart burst on click
  window.addEventListener('click', function (e) { burst(e.clientX, e.clientY, 10); });

  function burst(x, y, n) {
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2, d = 50 + Math.random() * 90;
      spawn(x, y, SPARKS[i % SPARKS.length], Math.cos(a) * d, Math.sin(a) * d - 30, 14 + Math.random() * 12, 900);
    }
  }

  // celebrate when a result or message appears
  var hit = document.querySelector('.result, .msg');
  if (hit) { var r = hit.getBoundingClientRect(); setTimeout(function () { burst(r.left + 40, r.top + 10, 18); }, 250); }

  // typewriter on the home page
  var t = document.querySelector('.type');
  if (t) {
    var words = JSON.parse(t.getAttribute('data-words')), w = 0, c = 0, del = false;
    (function tick() {
      var word = words[w];
      t.textContent = word.slice(0, c);
      if (!del && c === word.length) { del = true; return setTimeout(tick, 1400); }
      if (del && c === 0) { del = false; w = (w + 1) % words.length; }
      c += del ? -1 : 1;
      setTimeout(tick, del ? 40 : 90);
    })();
  }
})();
