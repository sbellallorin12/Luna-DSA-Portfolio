PI = 3.14159


def to_number(value):
    """Return a non-negative float, or None if the input is invalid."""
    try:
        n = float(value)
        return n if n >= 0 else None
    except (TypeError, ValueError):
        return None


def circle_area(radius):
    return round(PI * radius * radius, 2)


def triangle_area(base, height):
    return round(0.5 * base * height, 2)
