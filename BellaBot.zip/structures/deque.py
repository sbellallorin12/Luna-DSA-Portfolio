class Deque:
    """Double-ended queue: add or remove at either end."""

    def __init__(self):
        self.items = []

    def add_front(self, x):
        self.items.insert(0, x)

    def add_rear(self, x):
        self.items.append(x)

    def remove_front(self):
        return self.items.pop(0) if self.items else None

    def remove_rear(self):
        return self.items.pop() if self.items else None

    def clear(self):
        self.items.clear()
