PRECEDENCE = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}


def tokenize(expr):
    tokens, buf = [], ''
    for ch in expr:
        if ch.isalnum() or ch == '.':
            buf += ch
        else:
            if buf:
                tokens.append(buf)
                buf = ''
            if ch in PRECEDENCE or ch in '()':
                tokens.append(ch)
            elif not ch.isspace():
                raise ValueError(f'Unsupported character "{ch}".')
    if buf:
        tokens.append(buf)
    return tokens


def infix_to_postfix(expr):
    """Shunting-yard. Returns (postfix string, list of step dicts)."""
    output, stack, steps = [], [], []
    prev = None
    for t in tokenize(expr):
        if t not in PRECEDENCE and t not in '()':
            if prev is not None and (prev not in PRECEDENCE and prev != '('):
                raise ValueError('Two operands in a row.')
            output.append(t)
        elif t == '(':
            stack.append(t)
        elif t == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            if not stack:
                raise ValueError('Mismatched parentheses.')
            stack.pop()
        else:
            if prev is None or prev in PRECEDENCE or prev == '(':
                raise ValueError(f'Operator "{t}" is missing an operand.')
            while (stack and stack[-1] != '(' and
                   (PRECEDENCE[stack[-1]] > PRECEDENCE[t] or
                    (PRECEDENCE[stack[-1]] == PRECEDENCE[t] and t != '^'))):
                output.append(stack.pop())
            stack.append(t)
        prev = t
        steps.append({'token': t, 'stack': ' '.join(stack), 'output': ' '.join(output)})
    if prev is None:
        raise ValueError('Enter an expression.')
    if prev in PRECEDENCE:
        raise ValueError('Expression ends with an operator.')
    while stack:
        if stack[-1] == '(':
            raise ValueError('Mismatched parentheses.')
        output.append(stack.pop())
    return ' '.join(output), steps
